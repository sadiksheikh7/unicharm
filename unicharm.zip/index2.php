<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet" type="text/css" /> -->
	<link href="assets/css/style.css" rel="stylesheet" type="text/css" />
	<link href="assets/css/animate/animate.css" rel="stylesheet" type="text/css" />
	<link href="assets/css/vendor/slick/slick.css" rel="stylesheet" type="text/css" />
	<link href="assets/fonts/icomoon/icomoon.css" rel="stylesheet" type="text/css" />
	<link href="assets/css/vendor/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap"
		rel="stylesheet">
	<link rel="icon" href="images/fav.gif" type="image/gif" sizes="16x16">
</head>

<body>
	
<h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, eius. Consectetur quis at eveniet numquam, eos enim qui iusto tempore amet excepturi, quod aliquam nisi, officia eum quasi sed adipisci.</h2>
	
	<!-- <h1 class="animated wow fadeInLeft">dofjqaodijoidrgfjo9irgfjs</h1> -->
	<!-- <a href="javascript:void(0)" class="btn btn-default ripple-effect">dsoajid</a> -->
	<script type="text/javascript" src="assets/js/vendor/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/vendor/popper.min.js"></script>
	<script type="text/javascript" src="assets/js/vendor/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/animate/wow.min.js"></script>
	<script type="text/javascript" src="assets/js/vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="assets/js/custom.js"></script>

</body>

</html>